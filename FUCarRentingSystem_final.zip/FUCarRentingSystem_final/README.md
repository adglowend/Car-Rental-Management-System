# FUCarRentingSystem (Spring Boot + Spring Data JPA + Thymeleaf + SQL Server)

## Cách chạy
1. Mở SQL Server, chạy file `FUCarRentingSystem_DB.sql` để tạo DB `FUCarRentingSystemDB` cùng các bảng
   (cột `nvarchar` / `varchar` và các CHECK constraint đúng theo đề).
   - Nếu chỉ tạo DB trống, JPA vẫn tự tạo bảng khi chạy (`ddl-auto=update`), các cột `nvarchar` đã được khai báo bằng `@Nationalized`.
     Tuy nhiên bảng tạo bằng JPA không có hai CHECK constraint của script. Nếu DB đã có bảng cũ kiểu `varchar`,
     hãy xóa bảng/DB rồi tạo lại vì `update` không tự đổi kiểu cột.
2. Sửa `username` / `password` trong `src/main/resources/application.properties` cho đúng máy của bạn.
3. Chạy `CarRentingSystemApplication` (hoặc `mvnw spring-boot:run`), mở http://localhost:8080
4. Tài khoản Admin tự tạo lần đầu: `admin` / `123456`. Customer tự đăng ký ở trang Register.

## Cấu trúc 3 lớp
controller (nhận request) -> service (interface + impl, xử lý nghiệp vụ) -> repository (Spring Data JPA) -> entity (bảng DB)

- Validation: `@Valid` + Bean Validation trên entity Customer / Car (thông báo hiện dưới từng ô nhập).
- Lỗi nghiệp vụ: service ném `BusinessException`, `GlobalExceptionHandler` (@ControllerAdvice) báo lỗi và quay lại trang trước.

## Quy tắc nghiệp vụ chính
- Xóa xe: chưa có giao dịch thì xóa thật, đã có giao dịch thì chỉ đổi status thành `Deleted`.
- Trạng thái xe do hệ thống quản lý theo giao dịch (`Available` <-> `Rented`, `Deleted` khi xóa mềm). Xe mới luôn `Available`, form sửa xe không đổi status.
- Thuê nhiều xe trong một lần: mỗi xe là một dòng `car_rental`, cả lần thuê nằm trong một transaction (một xe lỗi thì hủy hết).
- Ngày trả phải sau ngày nhận. Customer không được chọn ngày nhận trong quá khứ, Admin được phép nhập giao dịch cũ.
- Báo cáo: lọc giao dịch có ngày nhận từ StartDate đến EndDate, sắp xếp ngày nhận giảm dần, kèm tổng doanh thu.
- Mật khẩu 6-72 ký tự, lưu dạng BCrypt.
