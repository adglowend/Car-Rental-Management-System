package fu.carrentingsystem.config;

import fu.carrentingsystem.entity.Account;
import fu.carrentingsystem.entity.CarProducer;
import fu.carrentingsystem.repository.AccountRepository;
import fu.carrentingsystem.repository.CarProducerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

// Chạy 1 lần khi khởi động: tạo tài khoản admin và vài hãng xe nếu chưa có
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final AccountRepository accountRepo;
    private final CarProducerRepository producerRepo;
    private final PasswordEncoder encoder;

    @Override
    public void run(String... args) {
        if (!accountRepo.existsByAccountName("admin")) {
            Account admin = new Account();
            admin.setAccountName("admin");
            admin.setEmail("admin@fu.com");
            admin.setPassword(encoder.encode("123456"));
            admin.setRole("Admin");
            accountRepo.save(admin);
        }
        if (producerRepo.count() == 0) {
            producerRepo.save(newProducer("Toyota", "Toyota City, Aichi", "Japan"));
            producerRepo.save(newProducer("Honda", "Minato, Tokyo", "Japan"));
            producerRepo.save(newProducer("VinFast", "Hai Phong", "Vietnam"));
        }
    }

    private CarProducer newProducer(String name, String address, String country) {
        CarProducer p = new CarProducer();
        p.setProducerName(name);
        p.setAddress(address);
        p.setCountry(country);
        return p;
    }
}
