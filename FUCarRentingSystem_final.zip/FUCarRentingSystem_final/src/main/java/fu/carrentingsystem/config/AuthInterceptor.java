package fu.carrentingsystem.config;

import fu.carrentingsystem.entity.Account;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.HandlerInterceptor;

// Kiểm tra đăng nhập và phân quyền Admin / Customer bằng session
public class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        String ctx = request.getContextPath();
        Account account = (Account) request.getSession().getAttribute("account");

        // Chưa đăng nhập -> về trang login
        if (account == null) {
            response.sendRedirect(ctx + "/login");
            return false;
        }
        String uri = request.getRequestURI();
        // Sai role -> về trang chủ (trang chủ sẽ chuyển đúng trang theo role)
        if (uri.startsWith(ctx + "/admin") && !"Admin".equals(account.getRole())) {
            response.sendRedirect(ctx + "/");
            return false;
        }
        if (uri.startsWith(ctx + "/customer") && !"Customer".equals(account.getRole())) {
            response.sendRedirect(ctx + "/");
            return false;
        }
        return true;
    }
}
