package fu.carrentingsystem.controller;

import fu.carrentingsystem.entity.Account;
import fu.carrentingsystem.entity.Customer;
import fu.carrentingsystem.service.CustomerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

// Admin quản lý khách hàng
@Controller
@RequestMapping("/admin/customers")
@RequiredArgsConstructor
public class AdminCustomerController {

    private final CustomerService customerService;

    @GetMapping
    public String list(Model model) {
        model.addAttribute("customers", customerService.findAll());
        return "admin/customer-list";
    }

    @GetMapping("/new")
    public String addForm(Model model) {
        return form(model, new Customer(), true);
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Integer id, Model model) {
        return form(model, customerService.findById(id), false);
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("customer") Customer customer, BindingResult result,
                       Model model, RedirectAttributes ra) {
        boolean isNew = customer.getCustomerId() == null;
        if (result.hasErrors()) {
            if (!isNew) {   // form sửa không gửi thông tin account, lấy lại từ DB để hiển thị
                customer.setAccount(customerService.findById(customer.getCustomerId()).getAccount());
            }
            return form(model, customer, isNew);
        }
        if (isNew) {
            customerService.create(customer);
        } else {
            customerService.update(customer.getCustomerId(), customer);
        }
        ra.addFlashAttribute("success", "Customer saved");
        return "redirect:/admin/customers";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Integer id, RedirectAttributes ra) {
        customerService.delete(id);   // không xóa được thì ném BusinessException
        ra.addFlashAttribute("success", "Customer deleted");
        return "redirect:/admin/customers";
    }

    // Chuẩn bị dữ liệu cho form dùng chung customer-form.html
    private String form(Model model, Customer customer, boolean isNew) {
        if (customer.getAccount() == null) customer.setAccount(new Account());
        model.addAttribute("customer", customer);
        model.addAttribute("isNew", isNew);
        model.addAttribute("title", isNew ? "Add customer" : "Edit customer");
        model.addAttribute("action", "/admin/customers/save");
        model.addAttribute("backUrl", "/admin/customers");
        return "customer-form";
    }
}
