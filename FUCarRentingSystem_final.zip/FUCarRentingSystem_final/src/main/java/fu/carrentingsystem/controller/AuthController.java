package fu.carrentingsystem.controller;

import fu.carrentingsystem.entity.Account;
import fu.carrentingsystem.entity.Customer;
import fu.carrentingsystem.service.AccountService;
import fu.carrentingsystem.service.CustomerService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

// Trang chủ, đăng nhập, đăng xuất, đăng ký
@Controller
@RequiredArgsConstructor
public class AuthController {

    private final AccountService accountService;
    private final CustomerService customerService;

    // Trang chủ: chuyển theo role
    @GetMapping("/")
    public String home(HttpSession session) {
        Account account = (Account) session.getAttribute("account");
        if (account == null) return "redirect:/login";
        return "Admin".equals(account.getRole()) ? "redirect:/admin/cars" : "redirect:/customer/rent";
    }

    @GetMapping("/login")
    public String loginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String accountName, @RequestParam String password,
                        HttpSession session, Model model) {
        Account account = accountService.login(accountName, password);
        if (account == null) {
            model.addAttribute("error", "Wrong account name or password");
            return "login";
        }
        session.setAttribute("account", account);
        return "redirect:/";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    // Đăng ký tài khoản customer (dùng chung form với trang quản lý customer)
    @GetMapping("/register")
    public String registerForm(Model model) {
        prepareForm(model, new Customer());
        return "customer-form";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("customer") Customer customer, BindingResult result,
                           Model model, RedirectAttributes ra) {
        if (result.hasErrors()) {          // lỗi validate -> hiện lại form kèm thông báo
            prepareForm(model, customer);
            return "customer-form";
        }
        customerService.create(customer);  // lỗi nghiệp vụ do GlobalExceptionHandler xử lý
        ra.addFlashAttribute("success", "Register successfully, please login");
        return "redirect:/login";
    }

    private void prepareForm(Model model, Customer customer) {
        if (customer.getAccount() == null) customer.setAccount(new Account());
        model.addAttribute("customer", customer);
        model.addAttribute("title", "Register");
        model.addAttribute("action", "/register");
        model.addAttribute("isNew", true);
        model.addAttribute("backUrl", "/login");
    }
}
