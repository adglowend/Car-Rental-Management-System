package fu.carrentingsystem.controller;

import fu.carrentingsystem.entity.Car;
import fu.carrentingsystem.entity.CarProducer;
import fu.carrentingsystem.service.CarService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

// Admin quản lý xe
@Controller
@RequestMapping("/admin/cars")
@RequiredArgsConstructor
public class AdminCarController {

    private final CarService carService;

    @GetMapping
    public String list(Model model) {
        model.addAttribute("cars", carService.findAll());
        return "admin/car-list";
    }

    @GetMapping("/new")
    public String addForm(Model model) {
        Car car = new Car();
        car.setProducer(new CarProducer());
        return form(model, car);
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Integer id, Model model) {
        return form(model, carService.findById(id));
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("car") Car car, BindingResult result,
                       Model model, RedirectAttributes ra) {
        if (result.hasErrors()) {          // lỗi validate -> hiện lại form
            return form(model, car);
        }
        carService.save(car);
        ra.addFlashAttribute("success", "Car saved");
        return "redirect:/admin/cars";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Integer id, RedirectAttributes ra) {
        boolean deleted = carService.delete(id);
        ra.addFlashAttribute("success", deleted ? "Car deleted"
                : "Car is in a rental transaction, so its status was changed to Deleted");
        return "redirect:/admin/cars";
    }

    private String form(Model model, Car car) {
        if (car.getProducer() == null) car.setProducer(new CarProducer());
        model.addAttribute("car", car);
        model.addAttribute("producers", carService.findAllProducers());
        model.addAttribute("title", car.getCarId() == null ? "Add car" : "Edit car");
        return "admin/car-form";
    }
}
