package fu.carrentingsystem.controller;

import fu.carrentingsystem.entity.CarRental;
import fu.carrentingsystem.service.CarService;
import fu.carrentingsystem.service.CustomerService;
import fu.carrentingsystem.service.RentalService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;

// Admin quản lý giao dịch thuê xe + báo cáo
// (lỗi nghiệp vụ như ngày sai, xe không rảnh do GlobalExceptionHandler xử lý)
@Controller
@RequestMapping("/admin/rentals")
@RequiredArgsConstructor
public class AdminRentalController {

    private final RentalService rentalService;
    private final CustomerService customerService;
    private final CarService carService;

    @GetMapping
    public String list(Model model) {
        model.addAttribute("rentals", rentalService.findAll());
        return "admin/rental-list";
    }

    // Form tạo giao dịch (dùng chung rental-form.html với customer)
    @GetMapping("/new")
    public String addForm(Model model) {
        model.addAttribute("customers", customerService.findAll());
        model.addAttribute("cars", carService.findAvailable());
        model.addAttribute("action", "/admin/rentals/create");
        model.addAttribute("backUrl", "/admin/rentals");
        return "rental-form";
    }

    @PostMapping("/create")
    public String create(@RequestParam Integer customerId,
                         @RequestParam(required = false) List<Integer> carIds,
                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate pickupDate,
                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate returnDate,
                         RedirectAttributes ra) {
        rentalService.rent(customerId, carIds, pickupDate, returnDate, true);   // admin được nhập ngày quá khứ
        ra.addFlashAttribute("success", "Rental created");
        return "redirect:/admin/rentals";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Integer id, Model model) {
        model.addAttribute("rental", rentalService.findById(id));
        return "admin/rental-edit";
    }

    @PostMapping("/update")
    public String update(@ModelAttribute CarRental rental, RedirectAttributes ra) {
        rentalService.update(rental.getCarRentId(), rental);
        ra.addFlashAttribute("success", "Rental updated");
        return "redirect:/admin/rentals";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Integer id, RedirectAttributes ra) {
        rentalService.delete(id);
        ra.addFlashAttribute("success", "Rental deleted");
        return "redirect:/admin/rentals";
    }

    // Báo cáo thống kê theo khoảng ngày
    @GetMapping("/report")
    public String report(@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                         @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
                         Model model) {
        model.addAttribute("startDate", startDate);
        model.addAttribute("endDate", endDate);
        if (startDate != null && endDate != null) {
            model.addAttribute("rentals", rentalService.report(startDate, endDate));
        }
        return "admin/report";
    }
}
