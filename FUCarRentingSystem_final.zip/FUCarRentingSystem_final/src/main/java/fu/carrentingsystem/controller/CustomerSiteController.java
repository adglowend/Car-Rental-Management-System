package fu.carrentingsystem.controller;

import fu.carrentingsystem.entity.Account;
import fu.carrentingsystem.entity.Customer;
import fu.carrentingsystem.service.CarService;
import fu.carrentingsystem.service.CustomerService;
import fu.carrentingsystem.service.RentalService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;

// Các chức năng của Customer: thuê xe, lịch sử, profile
@Controller
@RequestMapping("/customer")
@RequiredArgsConstructor
public class CustomerSiteController {

    private final CustomerService customerService;
    private final CarService carService;
    private final RentalService rentalService;

    // Lấy customer đang đăng nhập từ session
    private Customer currentCustomer(HttpSession session) {
        Account account = (Account) session.getAttribute("account");
        return customerService.findByAccountId(account.getAccountId());
    }

    // Form thuê xe (chọn 1 hoặc nhiều xe)
    @GetMapping("/rent")
    public String rentForm(Model model) {
        model.addAttribute("cars", carService.findAvailable());
        model.addAttribute("minDate", LocalDate.now());   // ô chọn ngày nhận không cho chọn quá khứ
        model.addAttribute("action", "/customer/rent");
        model.addAttribute("backUrl", "/customer/history");
        return "rental-form";
    }

    @PostMapping("/rent")
    public String rent(@RequestParam(required = false) List<Integer> carIds,
                       @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate pickupDate,
                       @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate returnDate,
                       HttpSession session, RedirectAttributes ra) {
        rentalService.rent(currentCustomer(session).getCustomerId(), carIds, pickupDate, returnDate, false);
        ra.addFlashAttribute("success", "Rent successfully");
        return "redirect:/customer/history";
    }

    @GetMapping("/history")
    public String history(HttpSession session, Model model) {
        model.addAttribute("rentals", rentalService.findByCustomer(currentCustomer(session).getCustomerId()));
        return "customer/history";
    }

    @GetMapping("/profile")
    public String profile(HttpSession session, Model model) {
        prepareForm(model, currentCustomer(session));
        return "customer-form";
    }

    @PostMapping("/profile")
    public String updateProfile(@Valid @ModelAttribute("customer") Customer form, BindingResult result,
                                HttpSession session, Model model, RedirectAttributes ra) {
        // Luôn dùng id của người đang đăng nhập, không tin id gửi từ form
        Customer me = currentCustomer(session);
        if (result.hasErrors()) {
            form.setAccount(me.getAccount());   // lấy lại thông tin account để hiển thị
            prepareForm(model, form);
            return "customer-form";
        }
        customerService.update(me.getCustomerId(), form);
        ra.addFlashAttribute("success", "Profile updated");
        return "redirect:/customer/profile";
    }

    private void prepareForm(Model model, Customer customer) {
        model.addAttribute("customer", customer);
        model.addAttribute("title", "My profile");
        model.addAttribute("action", "/customer/profile");
        model.addAttribute("isNew", false);
        model.addAttribute("backUrl", "/customer/rent");
    }
}
