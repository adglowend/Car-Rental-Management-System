package fu.carrentingsystem.exception;

// Lỗi nghiệp vụ (ví dụ: trùng email, xe không còn trống...). Được GlobalExceptionHandler xử lý
public class BusinessException extends RuntimeException {
    public BusinessException(String message) {
        super(message);
    }
}
