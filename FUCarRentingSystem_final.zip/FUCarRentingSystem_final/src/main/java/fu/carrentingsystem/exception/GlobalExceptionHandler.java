package fu.carrentingsystem.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.net.URI;

// Gom xử lý lỗi nghiệp vụ cho tất cả controller:
// báo lỗi bằng flash message rồi quay lại trang trước đó
@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(BusinessException.class)
    public String handleBusiness(BusinessException e, HttpServletRequest request, RedirectAttributes ra) {
        ra.addFlashAttribute("error", e.getMessage());

        String referer = request.getHeader("Referer");
        String back = "/";
        if (referer != null) {
            try {
                String path = URI.create(referer).getPath();   // chỉ lấy path để không redirect ra site khác
                if (path != null && path.startsWith("/") && !path.startsWith("//")) {
                    back = path;
                }
            } catch (IllegalArgumentException ignored) {
                // Referer sai định dạng -> về trang chủ
            }
        }
        return "redirect:" + back;
    }
}
