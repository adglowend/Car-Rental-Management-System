package fu.carrentingsystem.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Entity
@Table(name = "customer")
@Getter @Setter
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customer_id")
    private Integer customerId;

    @Nationalized
    @Column(name = "full_name", nullable = false, length = 200)
    @NotBlank(message = "Full name is required")
    @Size(max = 200, message = "Full name must be at most 200 characters")
    private String fullName;

    @Column(nullable = false, length = 15)   // varchar
    @Pattern(regexp = "\\d{9,15}", message = "Mobile must be 9-15 digits")
    private String mobile;

    @Column(nullable = false)
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @NotNull(message = "Birthday is required")
    @Past(message = "Birthday must be in the past")
    private LocalDate birthday;

    @Column(name = "identity_card", nullable = false, length = 20)   // varchar
    @NotBlank(message = "Identity card is required")
    @Size(max = 20, message = "Identity card must be at most 20 characters")
    private String identityCard;

    @Column(name = "licence_number", nullable = false, length = 20)   // varchar
    @NotBlank(message = "Licence number is required")
    @Size(max = 20, message = "Licence number must be at most 20 characters")
    private String licenceNumber;

    @Column(name = "licence_date", nullable = false)
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @NotNull(message = "Licence date is required")
    @PastOrPresent(message = "Licence date must not be in the future")
    private LocalDate licenceDate;

    // 1 customer có 1 account. cascade ALL: lưu/xóa customer thì account đi theo
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;
}
