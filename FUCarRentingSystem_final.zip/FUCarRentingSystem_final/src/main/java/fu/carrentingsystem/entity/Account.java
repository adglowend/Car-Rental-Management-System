package fu.carrentingsystem.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

@Entity
@Table(name = "account")
@Getter @Setter
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "account_id")
    private Integer accountId;

    @Nationalized   // nvarchar
    @Column(name = "account_name", nullable = false, length = 100)
    private String accountName;   // tên đăng nhập

    @Column(nullable = false, length = 200)   // varchar
    private String email;

    @Column(nullable = false, length = 200)   // varchar
    private String password;      // lưu dạng BCrypt

    @Nationalized   // nvarchar
    @Column(nullable = false, length = 10)
    private String role;          // "Admin" hoặc "Customer"
}
