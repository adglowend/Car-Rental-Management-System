package fu.carrentingsystem.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "car")
@Getter @Setter
public class Car {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "car_id")
    private Integer carId;

    @Nationalized
    @Column(name = "car_name", nullable = false, length = 200)
    @NotBlank(message = "Car name is required")
    @Size(max = 200, message = "Car name must be at most 200 characters")
    private String carName;

    @Column(name = "car_model_year", nullable = false)
    @NotNull(message = "Model year is required")
    @Min(value = 1900, message = "Model year must be from 1900")
    @Max(value = 2100, message = "Model year must be up to 2100")
    private Integer carModelYear;

    @Nationalized
    @Column(nullable = false, length = 50)
    @NotBlank(message = "Color is required")
    @Size(max = 50, message = "Color must be at most 50 characters")
    private String color;

    @Column(nullable = false)
    @NotNull(message = "Capacity is required")
    @Min(value = 1, message = "Capacity must be at least 1")
    private Integer capacity;

    @Nationalized
    @Column(nullable = false, length = 1000)
    @NotBlank(message = "Description is required")
    @Size(max = 1000, message = "Description must be at most 1000 characters")
    private String description;

    @Column(name = "import_date", nullable = false)
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @NotNull(message = "Import date is required")
    private LocalDate importDate;

    // Nhiều xe thuộc 1 nhà sản xuất
    @ManyToOne
    @JoinColumn(name = "producer_id", nullable = false)
    private CarProducer producer;

    @Column(name = "rent_price", nullable = false, precision = 10, scale = 0)
    @NotNull(message = "Rent price is required")
    @DecimalMin(value = "0", message = "Rent price must not be negative")
    @Digits(integer = 10, fraction = 0, message = "Rent price must be a whole number of up to 10 digits")
    private BigDecimal rentPrice;   // giá thuê / ngày

    @Nationalized
    @Column(nullable = false, length = 10)
    private String status;          // Available, Rented, Deleted
}
