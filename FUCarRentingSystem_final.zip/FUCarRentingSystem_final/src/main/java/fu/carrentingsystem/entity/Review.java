package fu.carrentingsystem.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

// Bảng review theo thiết kế DB của đề (đề chưa yêu cầu chức năng riêng cho review)
@Entity
@Table(name = "review")
@Getter @Setter
public class Review {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "car_rent_id", nullable = false)
    private CarRental carRental;

    @Column(name = "review_star", nullable = false)
    private int reviewStar;   // 1 - 5

    @Nationalized
    @Column(nullable = false, length = 500)
    private String comment;
}
