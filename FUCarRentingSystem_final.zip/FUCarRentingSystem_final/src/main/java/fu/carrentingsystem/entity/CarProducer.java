package fu.carrentingsystem.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

@Entity
@Table(name = "car_producer")
@Getter @Setter
public class CarProducer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "producer_id")
    private Integer producerId;

    @Nationalized
    @Column(name = "producer_name", nullable = false, length = 100)
    private String producerName;

    @Nationalized
    @Column(nullable = false, length = 200)
    private String address;

    @Nationalized
    @Column(nullable = false, length = 100)
    private String country;
}
