package fu.carrentingsystem.service.impl;

import fu.carrentingsystem.entity.Car;
import fu.carrentingsystem.entity.CarProducer;
import fu.carrentingsystem.repository.CarProducerRepository;
import fu.carrentingsystem.repository.CarRentalRepository;
import fu.carrentingsystem.repository.CarRepository;
import fu.carrentingsystem.exception.BusinessException;
import fu.carrentingsystem.service.CarService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CarServiceImpl implements CarService {

    private final CarRepository carRepo;
    private final CarProducerRepository producerRepo;
    private final CarRentalRepository rentalRepo;

    @Override
    public List<Car> findAll() {
        return carRepo.findAll();
    }

    // Xe đang rảnh, khách mới được thuê
    @Override
    public List<Car> findAvailable() {
        return carRepo.findByStatus("Available");
    }

    @Override
    public Car findById(Integer id) {
        return carRepo.findById(id).orElseThrow(() -> new BusinessException("Car not found"));
    }

    @Override
    public List<CarProducer> findAllProducers() {
        return producerRepo.findAll();
    }

    // Thêm mới hoặc sửa (carId null = thêm mới)
    // Status do hệ thống quản lý theo giao dịch thuê: xe mới luôn Available, sửa thì giữ nguyên status cũ
    @Override
    public void save(Car car) {
        if (car.getCarId() == null) {
            car.setStatus("Available");
        } else {
            car.setStatus(findById(car.getCarId()).getStatus());
        }
        carRepo.save(car);
    }

    // Xe chưa có giao dịch -> xóa thật. Đã có giao dịch -> chỉ đổi status = Deleted
    // Trả về true nếu đã xóa thật
    @Override
    public boolean delete(Integer id) {
        Car car = findById(id);
        if (rentalRepo.existsByCar_CarId(id)) {
            car.setStatus("Deleted");
            carRepo.save(car);
            return false;
        }
        carRepo.delete(car);
        return true;
    }
}
