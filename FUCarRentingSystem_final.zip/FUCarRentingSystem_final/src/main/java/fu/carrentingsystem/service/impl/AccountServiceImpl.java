package fu.carrentingsystem.service.impl;

import fu.carrentingsystem.entity.Account;
import fu.carrentingsystem.repository.AccountRepository;
import fu.carrentingsystem.service.AccountService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepo;
    private final PasswordEncoder encoder;

    @Override
    public Account login(String accountName, String password) {
        Account account = accountRepo.findByAccountName(accountName);
        if (account != null && encoder.matches(password, account.getPassword())) {
            return account;
        }
        return null;
    }
}
