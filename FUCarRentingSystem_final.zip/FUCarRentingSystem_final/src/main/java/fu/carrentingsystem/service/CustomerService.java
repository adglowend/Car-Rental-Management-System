package fu.carrentingsystem.service;

import fu.carrentingsystem.entity.Customer;

import java.util.List;

public interface CustomerService {
    List<Customer> findAll();
    Customer findById(Integer id);
    Customer findByAccountId(Integer accountId);
    void create(Customer customer);              // Register / Admin thêm khách
    void update(Integer id, Customer form);      // sửa thông tin cá nhân (+ đổi mật khẩu nếu có nhập)
    void delete(Integer id);
}
