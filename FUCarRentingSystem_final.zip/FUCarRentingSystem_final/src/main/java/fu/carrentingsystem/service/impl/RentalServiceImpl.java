package fu.carrentingsystem.service.impl;

import fu.carrentingsystem.entity.Car;
import fu.carrentingsystem.entity.CarRental;
import fu.carrentingsystem.entity.Customer;
import fu.carrentingsystem.repository.CarRentalRepository;
import fu.carrentingsystem.repository.CarRepository;
import fu.carrentingsystem.repository.CustomerRepository;
import fu.carrentingsystem.exception.BusinessException;
import fu.carrentingsystem.service.RentalService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RentalServiceImpl implements RentalService {

    private final CarRentalRepository rentalRepo;
    private final CarRepository carRepo;
    private final CustomerRepository customerRepo;

    @Override
    public List<CarRental> findAll() {
        return rentalRepo.findAll();
    }

    @Override
    public CarRental findById(Integer id) {
        return rentalRepo.findById(id).orElseThrow(() -> new BusinessException("Rental not found"));
    }

    @Override
    public List<CarRental> findByCustomer(Integer customerId) {
        return rentalRepo.findByCustomer_CustomerIdOrderByPickupDateDesc(customerId);
    }

    // Tạo giao dịch thuê 1 hoặc nhiều xe: mỗi xe là 1 dòng car_rental
    @Transactional
    @Override
    public void rent(Integer customerId, List<Integer> carIds, LocalDate pickup, LocalDate returnDate,
                     boolean allowPast) {
        if (carIds == null || carIds.isEmpty()) {
            throw new BusinessException("Please choose at least one car");
        }
        checkDates(pickup, returnDate);
        if (!allowPast) {
            checkPickupNotPast(pickup);   // customer không được chọn ngày nhận trong quá khứ
        }

        Customer customer = customerRepo.findById(customerId)
                .orElseThrow(() -> new BusinessException("Customer not found"));
        long days = ChronoUnit.DAYS.between(pickup, returnDate);

        for (Integer carId : carIds) {
            Car car = carRepo.findById(carId).orElseThrow(() -> new BusinessException("Car not found"));
            if (!"Available".equals(car.getStatus())) {
                throw new BusinessException(car.getCarName() + " is not available");
            }
            CarRental rental = new CarRental();
            rental.setCustomer(customer);
            rental.setCar(car);
            rental.setPickupDate(pickup);
            rental.setReturnDate(returnDate);
            rental.setRentPrice(car.getRentPrice().multiply(BigDecimal.valueOf(days)));
            rental.setStatus("Active");
            rentalRepo.save(rental);

            car.setStatus("Rented");   // xe đang được thuê
            carRepo.save(car);
        }
    }

    // Admin sửa ngày thuê / trạng thái
    @Transactional
    @Override
    public void update(Integer id, CarRental form) {
        if (id == null) {
            throw new BusinessException("Rental not found");
        }
        checkDates(form.getPickupDate(), form.getReturnDate());

        String newStatus = form.getStatus();
        if (!"Active".equals(newStatus) && !"Completed".equals(newStatus)) {
            throw new BusinessException("Invalid status");
        }

        CarRental rental = findById(id);
        String oldStatus = rental.getStatus();
        Car car = rental.getCar();

        // Chỉ đổi trạng thái xe khi trạng thái giao dịch thật sự thay đổi
        // (xe đã Deleted thì giữ nguyên)
        if (!newStatus.equals(oldStatus) && !"Deleted".equals(car.getStatus())) {
            if ("Completed".equals(newStatus)) {
                car.setStatus("Available");           // trả xe
            } else {                                  // Completed -> Active: xe phải đang rảnh
                if (!"Available".equals(car.getStatus())) {
                    throw new BusinessException(car.getCarName() + " is not available");
                }
                car.setStatus("Rented");
            }
            carRepo.save(car);
        }

        rental.setPickupDate(form.getPickupDate());
        rental.setReturnDate(form.getReturnDate());
        long days = ChronoUnit.DAYS.between(form.getPickupDate(), form.getReturnDate());
        rental.setRentPrice(car.getRentPrice().multiply(BigDecimal.valueOf(days)));
        rental.setStatus(newStatus);
        rentalRepo.save(rental);
    }

    @Transactional
    @Override
    public void delete(Integer id) {
        CarRental rental = findById(id);
        Car car = rental.getCar();
        // Xóa giao dịch đang Active thì trả xe về Available
        if ("Active".equals(rental.getStatus()) && !"Deleted".equals(car.getStatus())) {
            car.setStatus("Available");
            carRepo.save(car);
        }
        rentalRepo.delete(rental);
    }

    // Báo cáo từ StartDate đến EndDate, sắp xếp giảm dần theo ngày thuê
    @Override
    public List<CarRental> report(LocalDate start, LocalDate end) {
        if (end.isBefore(start)) {
            throw new BusinessException("End date must not be before start date");
        }
        return rentalRepo.findByPickupDateBetweenOrderByPickupDateDesc(start, end);
    }

    // Ngày trả phải sau ngày nhận
    private void checkDates(LocalDate pickup, LocalDate returnDate) {
        if (pickup == null || returnDate == null || !returnDate.isAfter(pickup)) {
            throw new BusinessException("Return date must be after pickup date");
        }
    }

    // Ngày nhận xe không được ở quá khứ (chỉ áp dụng khi customer thuê)
    private void checkPickupNotPast(LocalDate pickup) {
        if (pickup.isBefore(LocalDate.now())) {
            throw new BusinessException("Pickup date must not be in the past");
        }
    }
}
