package fu.carrentingsystem.service;

import fu.carrentingsystem.entity.Car;
import fu.carrentingsystem.entity.CarProducer;

import java.util.List;

public interface CarService {
    List<Car> findAll();
    List<Car> findAvailable();                   // xe đang rảnh
    Car findById(Integer id);
    List<CarProducer> findAllProducers();
    void save(Car car);                          // thêm mới hoặc sửa
    boolean delete(Integer id);                  // true = đã xóa thật, false = chỉ đổi status Deleted
}
