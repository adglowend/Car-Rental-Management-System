package fu.carrentingsystem.service.impl;

import fu.carrentingsystem.entity.Account;
import fu.carrentingsystem.entity.Customer;
import fu.carrentingsystem.repository.AccountRepository;
import fu.carrentingsystem.repository.CarRentalRepository;
import fu.carrentingsystem.repository.CustomerRepository;
import fu.carrentingsystem.exception.BusinessException;
import fu.carrentingsystem.service.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepo;
    private final AccountRepository accountRepo;
    private final CarRentalRepository rentalRepo;
    private final PasswordEncoder encoder;

    @Override
    public List<Customer> findAll() {
        return customerRepo.findAll();
    }

    @Override
    public Customer findById(Integer id) {
        return customerRepo.findById(id).orElseThrow(() -> new BusinessException("Customer not found"));
    }

    @Override
    public Customer findByAccountId(Integer accountId) {
        return customerRepo.findByAccount_AccountId(accountId);
    }

    // Tạo customer mới (kèm account). Dùng cho Register và Admin thêm khách
    @Override
    public void create(Customer customer) {
        Account account = customer.getAccount();
        if (account == null) {
            throw new BusinessException("Account information is required");
        }
        // Luôn là thêm mới: bỏ id do client gửi lên để không ghi đè customer/account có sẵn
        customer.setCustomerId(null);
        account.setAccountId(null);

        if (isBlank(account.getAccountName()) || isBlank(account.getEmail())) {
            throw new BusinessException("Account name and email are required");
        }
        if (account.getAccountName().length() > 100) {
            throw new BusinessException("Account name must be at most 100 characters");
        }
        if (account.getEmail().length() > 200) {
            throw new BusinessException("Email must be at most 200 characters");
        }
        checkPassword(account.getPassword());
        if (accountRepo.existsByAccountName(account.getAccountName())) {
            throw new BusinessException("Account name already exists");
        }
        if (accountRepo.existsByEmail(account.getEmail())) {
            throw new BusinessException("Email already exists");
        }
        account.setPassword(encoder.encode(account.getPassword()));
        account.setRole("Customer");
        customerRepo.save(customer);   // cascade: lưu luôn account
    }

    // Cập nhật thông tin cá nhân. Nếu có nhập mật khẩu mới thì đổi mật khẩu
    @Transactional
    @Override
    public void update(Integer id, Customer form) {
        Customer c = findById(id);
        c.setFullName(form.getFullName());
        c.setMobile(form.getMobile());
        c.setBirthday(form.getBirthday());
        c.setIdentityCard(form.getIdentityCard());
        c.setLicenceNumber(form.getLicenceNumber());
        c.setLicenceDate(form.getLicenceDate());

        String newPassword = form.getAccount() == null ? null : form.getAccount().getPassword();
        if (newPassword != null && !newPassword.isBlank()) {
            checkPassword(newPassword);
            c.getAccount().setPassword(encoder.encode(newPassword));
        }
        customerRepo.save(c);
    }

    // Không cho xóa khách đã có giao dịch thuê xe
    @Override
    public void delete(Integer id) {
        if (rentalRepo.existsByCustomer_CustomerId(id)) {
            throw new BusinessException("Cannot delete: this customer has rental transactions");
        }
        customerRepo.delete(findById(id));   // cascade: xóa luôn account
    }

    // Mật khẩu 6-72 ký tự (BCrypt chỉ dùng tối đa 72 byte đầu)
    private void checkPassword(String password) {
        if (password == null || password.length() < 6 || password.length() > 72) {
            throw new BusinessException("Password must be 6-72 characters");
        }
    }

    private boolean isBlank(String text) {
        return text == null || text.isBlank();
    }
}
