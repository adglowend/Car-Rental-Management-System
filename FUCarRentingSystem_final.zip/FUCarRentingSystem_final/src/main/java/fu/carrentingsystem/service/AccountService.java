package fu.carrentingsystem.service;

import fu.carrentingsystem.entity.Account;

public interface AccountService {
    // Trả về Account nếu đăng nhập đúng, ngược lại trả về null
    Account login(String accountName, String password);
}
