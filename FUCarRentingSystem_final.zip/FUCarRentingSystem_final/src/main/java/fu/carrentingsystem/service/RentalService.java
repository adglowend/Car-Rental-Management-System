package fu.carrentingsystem.service;

import fu.carrentingsystem.entity.CarRental;

import java.time.LocalDate;
import java.util.List;

public interface RentalService {
    List<CarRental> findAll();
    CarRental findById(Integer id);
    List<CarRental> findByCustomer(Integer customerId);
    // allowPast = true: cho phép ngày nhận trong quá khứ (admin nhập giao dịch); false: dành cho customer
    void rent(Integer customerId, List<Integer> carIds, LocalDate pickup, LocalDate returnDate, boolean allowPast);
    void update(Integer id, CarRental form);
    void delete(Integer id);
    List<CarRental> report(LocalDate start, LocalDate end);
}
