package fu.carrentingsystem.repository;

import fu.carrentingsystem.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
    Customer findByAccount_AccountId(Integer accountId);
}
