package fu.carrentingsystem.repository;

import fu.carrentingsystem.entity.CarProducer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarProducerRepository extends JpaRepository<CarProducer, Integer> {
}
