package fu.carrentingsystem.repository;

import fu.carrentingsystem.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepository extends JpaRepository<Account, Integer> {
    Account findByAccountName(String accountName);
    boolean existsByAccountName(String accountName);
    boolean existsByEmail(String email);
}
