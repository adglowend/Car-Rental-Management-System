package fu.carrentingsystem.repository;

import fu.carrentingsystem.entity.Car;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CarRepository extends JpaRepository<Car, Integer> {
    List<Car> findByStatus(String status);
}
