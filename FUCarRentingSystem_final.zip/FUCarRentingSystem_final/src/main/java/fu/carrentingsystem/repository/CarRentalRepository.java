package fu.carrentingsystem.repository;

import fu.carrentingsystem.entity.CarRental;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface CarRentalRepository extends JpaRepository<CarRental, Integer> {
    boolean existsByCar_CarId(Integer carId);
    boolean existsByCustomer_CustomerId(Integer customerId);

    // Lịch sử thuê của 1 khách, mới nhất trước
    List<CarRental> findByCustomer_CustomerIdOrderByPickupDateDesc(Integer customerId);

    // Báo cáo theo khoảng ngày, sắp xếp giảm dần
    List<CarRental> findByPickupDateBetweenOrderByPickupDateDesc(LocalDate start, LocalDate end);
}
